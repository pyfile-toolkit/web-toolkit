from setuptools import setup, find_packages

with open("README.md", "r") as f:
    long_description = f.read()

setup(
    name="pyfile-toolkit",
    version="1.0.0",
    author="PyFile Tools",
    description="Smart File Organizer & Batch Processor — organize, rename, deduplicate files",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pyfile-toolkit/pyfile-toolkit",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Utilities",
        "Topic :: System :: Filesystems",
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "pyfile-toolkit=pyfile_toolkit:main",
        ],
    },
)
