#!/usr/bin/env python3
"""
PyFile Toolkit - Smart File Organizer & Batch Processor
A production-ready file management utility.
"""

import os
import sys
import shutil
import hashlib
import re
import zipfile
import argparse
from pathlib import Path
from datetime import datetime
from collections import defaultdict
from typing import Optional

VERSION = "1.0.0"

# --- File Type Categories ---
FILE_CATEGORIES = {
    "Images": {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp", ".ico", ".tiff", ".heic"},
    "Documents": {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".csv", ".json", ".xml", ".md", ".rst", ".odt", ".rtf"},
    "Audio": {".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma", ".m4a", ".opus"},
    "Video": {".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm", ".m4v"},
    "Archives": {".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz"},
    "Code": {".py", ".js", ".ts", ".html", ".css", ".java", ".cpp", ".c", ".h", ".go", ".rs", ".rb", ".php", ".sh", ".bash", ".sql", ".swift", ".kt"},
    "Executables": {".exe", ".msi", ".app", ".deb", ".rpm", ".AppImage"},
}

def get_category(ext: str) -> str:
    ext = ext.lower()
    for cat, exts in FILE_CATEGORIES.items():
        if ext in exts:
            return cat
    return "Other"

def get_file_hash(filepath: Path, algorithm: str = "md5", chunk_size: int = 8192) -> str:
    """Compute file hash efficiently."""
    h = hashlib.new(algorithm)
    with open(filepath, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()

# --- Organize Command ---
def organize(directory: str, recursive: bool = False, dry_run: bool = False) -> dict:
    """Organize files into category folders."""
    path = Path(directory).expanduser().resolve()
    if not path.is_dir():
        print(f"Error: '{directory}' is not a valid directory.")
        sys.exit(1)
    
    stats = {"moved": 0, "skipped": 0, "errors": 0}
    pattern = "**/*" if recursive else "*"
    
    for filepath in path.glob(pattern):
        if not filepath.is_file():
            continue
        if filepath.parent != path and not recursive:
            continue
        
        ext = filepath.suffix
        category = get_category(ext)
        dest_dir = path / category
        
        if filepath.parent == dest_dir:
            stats["skipped"] += 1
            continue
        
        if not dry_run:
            dest_dir.mkdir(exist_ok=True)
            try:
                shutil.move(str(filepath), str(dest_dir / filepath.name))
                stats["moved"] += 1
            except Exception as e:
                print(f"Error moving {filepath}: {e}")
                stats["errors"] += 1
        else:
            stats["moved"] += 1
    
    return stats

# --- Rename Command ---
def rename(directory: str, pattern: str, regex: Optional[str] = None,
           case: Optional[str] = None, dry_run: bool = False) -> dict:
    """Batch rename files with pattern or regex."""
    path = Path(directory).expanduser().resolve()
    if not path.is_dir():
        print(f"Error: '{directory}' is not a valid directory.")
        sys.exit(1)
    
    stats = {"renamed": 0, "skipped": 0, "errors": 0}
    files = sorted([f for f in path.iterdir() if f.is_file()])
    
    for i, filepath in enumerate(files, 1):
        stem = filepath.stem
        ext = filepath.suffix
        
        if regex:
            try:
                new_stem = re.sub(regex[0], regex[1], stem) if isinstance(regex, (list, tuple)) else re.sub(regex, "", stem)
            except re.error as e:
                print(f"Regex error: {e}")
                stats["errors"] += 1
                continue
        elif case == "upper":
            new_stem = stem.upper()
        elif case == "lower":
            new_stem = stem.lower()
        elif case == "title":
            new_stem = stem.title()
        else:
            # Pattern with ### for numbering
            new_stem = pattern.replace("###", str(i).zfill(3))
            new_stem = new_stem.replace("##", str(i).zfill(2))
            new_stem = new_stem.replace("#", str(i))
        
        new_name = new_stem + ext
        new_path = path / new_name
        
        if new_path == filepath:
            stats["skipped"] += 1
            continue
        
        if new_path.exists():
            print(f"Warning: '{new_name}' already exists, skipping.")
            stats["skipped"] += 1
            continue
        
        if not dry_run:
            try:
                filepath.rename(new_path)
                stats["renamed"] += 1
            except Exception as e:
                print(f"Error renaming {filepath}: {e}")
                stats["errors"] += 1
        else:
            stats["renamed"] += 1
    
    return stats

# --- Dedupe Command ---
def dedupe(directory: str, action: str = "list", recursive: bool = False, 
           algorithm: str = "sha256", dry_run: bool = False) -> dict:
    """Find and manage duplicate files."""
    path = Path(directory).expanduser().resolve()
    if not path.is_dir():
        print(f"Error: '{directory}' is not a valid directory.")
        sys.exit(1)
    
    # First pass: group by size
    size_map = defaultdict(list)
    pattern = "**/*" if recursive else "*"
    
    for filepath in path.glob(pattern):
        if filepath.is_file():
            try:
                size_map[filepath.stat().st_size].append(filepath)
            except OSError:
                continue
    
    # Second pass: hash files with same size
    hash_map = defaultdict(list)
    stats = {"scanned": 0, "duplicates": 0, "freed": 0}
    
    for size, files in size_map.items():
        if len(files) < 2:
            continue
        for fp in files:
            try:
                fhash = get_file_hash(fp, algorithm)
                hash_map[fhash].append(fp)
                stats["scanned"] += 1
            except OSError:
                continue
    
    # Process duplicates
    for fhash, files in hash_map.items():
        if len(files) < 2:
            continue
        
        original = min(files, key=lambda f: f.stat().st_mtime)  # Keep oldest
        dups = [f for f in files if f != original]
        
        stats["duplicates"] += len(dups)
        
        if action == "list":
            print(f"\nDuplicate set (hash: {fhash[:16]}...):")
            print(f"  [KEEP] {original}")
            for d in dups:
                print(f"  [DUP]  {d}")
        elif action == "delete":
            for d in dups:
                if not dry_run:
                    try:
                        size = d.stat().st_size
                        d.unlink()
                        stats["freed"] += size
                    except OSError as e:
                        print(f"Error deleting {d}: {e}")
        
        elif action == "move":
            dup_dir = path / "_duplicates"
            if not dry_run:
                dup_dir.mkdir(exist_ok=True)
                for d in dups:
                    try:
                        shutil.move(str(d), str(dup_dir / d.name))
                    except OSError as e:
                        print(f"Error moving {d}: {e}")
    
    return stats

# --- Clean command ---
def clean_empty_dirs(directory: str, dry_run: bool = False) -> dict:
    """Remove empty directories recursively."""
    path = Path(directory).expanduser().resolve()
    stats = {"removed": 0}
    
    for dirpath in sorted(path.rglob("*"), reverse=True):
        if dirpath.is_dir() and not any(dirpath.iterdir()):
            if not dry_run:
                try:
                    dirpath.rmdir()
                    stats["removed"] += 1
                except OSError:
                    pass
            else:
                stats["removed"] += 1
    
    return stats

# --- Bulk Compress ---
def bulk_compress(directory: str, output: Optional[str] = None, 
                  fmt: str = "zip", dry_run: bool = False) -> dict:
    """Compress each subfolder into a separate archive."""
    path = Path(directory).expanduser().resolve()
    stats = {"compressed": 0, "errors": 0}
    output_dir = Path(output).expanduser().resolve() if output else path
    
    for subdir in path.iterdir():
        if not subdir.is_dir():
            continue
        
        archive_path = output_dir / f"{subdir.name}.{fmt}"
        
        if fmt == "zip":
            if not dry_run:
                try:
                    with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as zf:
                        for f in subdir.rglob("*"):
                            if f.is_file():
                                zf.write(f, f.relative_to(subdir))
                    stats["compressed"] += 1
                except Exception as e:
                    print(f"Error compressing {subdir}: {e}")
                    stats["errors"] += 1
            else:
                stats["compressed"] += 1
    
    return stats

# --- CLI ---
def main():
    parser = argparse.ArgumentParser(
        description=f"PyFile Toolkit v{VERSION} — Smart File Organizer & Batch Processor",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pyfile-toolkit organize ~/Downloads
  pyfile-toolkit rename ~/Photos --pattern "vacation_###"
  pyfile-toolkit dedupe ~/Documents --action list
  pyfile-toolkit clean ~/Projects
  pyfile-toolkit compress ~/Backups --fmt zip
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # organize
    org = subparsers.add_parser("organize", help="Organize files into category folders")
    org.add_argument("directory", help="Directory to organize")
    org.add_argument("-r", "--recursive", action="store_true", help="Scan recursively")
    org.add_argument("--dry-run", action="store_true", help="Show what would be done")
    
    # rename
    ren = subparsers.add_parser("rename", help="Batch rename files")
    ren.add_argument("directory", help="Directory containing files")
    ren.add_argument("--pattern", default="file_###", help="Rename pattern (# for numbers)")
    ren.add_argument("--regex", nargs="+", help="Regex pattern and replacement")
    ren.add_argument("--case", choices=["upper", "lower", "title"], help="Change case")
    ren.add_argument("--dry-run", action="store_true", help="Show what would be done")
    
    # dedupe
    ded = subparsers.add_parser("dedupe", help="Find and manage duplicate files")
    ded.add_argument("directory", help="Directory to scan")
    ded.add_argument("--action", choices=["list", "delete", "move"], default="list",
                     help="Action for duplicates")
    ded.add_argument("-r", "--recursive", action="store_true", help="Scan recursively")
    ded.add_argument("--algorithm", default="sha256", help="Hash algorithm")
    ded.add_argument("--dry-run", action="store_true", help="Show what would be done")
    
    # clean
    cln = subparsers.add_parser("clean", help="Remove empty directories")
    cln.add_argument("directory", help="Directory to clean")
    cln.add_argument("--dry-run", action="store_true", help="Show what would be done")
    
    # compress
    cmp = subparsers.add_parser("compress", help="Bulk compress subfolders")
    cmp.add_argument("directory", help="Directory with subfolders to compress")
    cmp.add_argument("--output", help="Output directory for archives")
    cmp.add_argument("--fmt", default="zip", choices=["zip"], help="Archive format")
    cmp.add_argument("--dry-run", action="store_true", help="Show what would be done")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    cmd = args.command
    dry = getattr(args, "dry_run", False)
    
    if cmd == "organize":
        stats = organize(args.directory, args.recursive, dry)
        print(f"Organized: {stats['moved']} moved, {stats['skipped']} skipped, {stats['errors']} errors")
    
    elif cmd == "rename":
        regex = tuple(args.regex) if args.regex else None
        stats = rename(args.directory, args.pattern, regex, args.case, dry)
        print(f"Renamed: {stats['renamed']} files, {stats['skipped']} skipped, {stats['errors']} errors")
    
    elif cmd == "dedupe":
        stats = dedupe(args.directory, args.action, getattr(args, "recursive", False), 
                       args.algorithm, dry)
        freed_mb = stats.get("freed", 0) / (1024 * 1024)
        print(f"Dedupe: {stats['scanned']} scanned, {stats['duplicates']} duplicates found")
        if stats.get("freed"):
            print(f"Freed: {freed_mb:.1f} MB")
    
    elif cmd == "clean":
        stats = clean_empty_dirs(args.directory, dry)
        print(f"Cleaned: {stats['removed']} empty directories removed")
    
    elif cmd == "compress":
        stats = bulk_compress(args.directory, getattr(args, "output", None), args.fmt, dry)
        print(f"Compressed: {stats['compressed']} archives created, {stats['errors']} errors")

if __name__ == "__main__":
    main()
