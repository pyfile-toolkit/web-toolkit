# PyFile Toolkit — Smart File Organizer & Batch Processor

A powerful Python CLI tool to organize, rename, deduplicate, and batch-process files.

## Features
- **Smart Organize**: Sort files by type, date, size into folders
- **Batch Rename**: Regex, pattern, case-change, sequential numbering
- **Duplicate Finder**: Find and manage duplicate files (by hash)
- **Bulk Compress/Extract**: Zip/unzip multiple files at once
- **Clean Empty Dirs**: Remove empty directories recursively

## Quick Start
```bash
pip install pyfile-toolkit
pyfile-toolkit organize ~/Downloads
pyfile-toolkit dedupe ~/Documents
pyfile-toolkit rename ~/Photos --pattern "vacation_###"
```

## Pricing
Free tier: 100 files/day. Pro: $4.99 one-time, unlimited.
